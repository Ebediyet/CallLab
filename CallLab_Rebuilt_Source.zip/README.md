# CallLab 0.1 — yeniden yazılmış Android test uygulaması

Bu proje sıfırdan yazılmıştır; üçüncü taraf arama kaydı motoru içermez.

## Şu anda çalışan işlevler (derlenip cihazda doğrulanması gerekir)
- Türkçe arayüz
- Kullanıcının başlattığı mikrofon kaydı, ön plan servisi ile M4A/AAC
- Uygulama özel klasöründe kayıtları listeleme, dinleme, silme
- Shizuku paketinin kurulu olup olmadığını kontrol etme
- İnternet izni yok

## Henüz yapılmayanlar
- Shizuku API bağlantısı ve yetki isteği
- Aramayı otomatik algılama
- İki taraflı telefon görüşmesi kaydı

Android 15'te Shizuku shell erişimi, korumalı VOICE_CALL ses kaynağını otomatik açmaz.

## GitHub Actions
Depo köküne tüm dosyaları (gizli `.github` klasörü dahil) yükleyin.
Actions > Build CallLab APK > Run workflow.
Başarılıysa Artifacts > CallLab-debug-apk içindeki app-debug.apk dosyasını indirin.

Not: `gradlew` dosyası yok; workflow Gradle 8.10.2 kurar.
