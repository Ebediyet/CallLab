package com.calllab.app;

import android.app.*;
import android.content.*;
import android.media.MediaRecorder;
import android.os.*;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RecordingService extends Service {
    public static final String ACTION_START="com.calllab.app.START";
    public static final String ACTION_STOP="com.calllab.app.STOP";
    public static final String ACTION_CHANGED="com.calllab.app.CHANGED";
    private static final String CHANNEL="recording";
    private MediaRecorder recorder;
    private boolean active=false;
    private File output;
    @Override public void onCreate() {
        super.onCreate();
        NotificationManager nm=getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Ses kaydı",NotificationManager.IMPORTANCE_LOW));
    }
    private Notification notification(String text) {
        Intent intent=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,0,intent,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this,CHANNEL).setContentTitle("CallLab").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).setOngoing(true).build();
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        String action=intent==null?"":intent.getAction();
        if(ACTION_STOP.equals(action)) { stopRecording(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY; }
        if(ACTION_START.equals(action) && !active) {
            startForeground(1,notification("Mikrofon kaydı hazırlanıyor"));
            try { startRecording(); getSystemService(NotificationManager.class).notify(1,notification("Mikrofon kaydı sürüyor")); }
            catch(Exception ex) { if(output!=null) output.delete(); broadcast("Kayıt başlatılamadı: "+ex.getMessage()); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); }
        }
        return START_NOT_STICKY;
    }
    private void startRecording() throws IOException {
        File dir=new File(getFilesDir(),"recordings");
        if(!dir.exists() && !dir.mkdirs()) throw new IOException("Kayıt klasörü açılamadı");
        output=new File(dir,"Kayit_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".m4a");
        recorder=android.os.Build.VERSION.SDK_INT>=31?new MediaRecorder(this):new MediaRecorder();
        recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        recorder.setAudioEncodingBitRate(128000);
        recorder.setAudioSamplingRate(44100);
        recorder.setOutputFile(output.getAbsolutePath());
        recorder.prepare(); recorder.start(); active=true; broadcast("Kayıt başladı");
    }
    private void stopRecording() {
        if(recorder!=null) {
            boolean ok=true;
            try { if(active) recorder.stop(); } catch(RuntimeException e) { ok=false; }
            try { recorder.reset(); recorder.release(); } catch(Exception ignored) {}
            recorder=null; active=false;
            if(!ok && output!=null) output.delete();
        }
        broadcast("Kayıt durduruldu");
    }
    private void broadcast(String msg) {
        Intent i=new Intent(ACTION_CHANGED); i.setPackage(getPackageName()); i.putExtra("message",msg); sendBroadcast(i);
    }
    @Override public void onDestroy() { stopRecording(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
