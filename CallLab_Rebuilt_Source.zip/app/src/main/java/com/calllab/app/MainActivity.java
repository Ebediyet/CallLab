package com.calllab.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.File;
import java.text.DateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout root,files;
    private TextView status;
    private MediaPlayer player;
    private boolean recording=false;
    private final BroadcastReceiver receiver=new BroadcastReceiver() {
        @Override public void onReceive(Context c,Intent i) {
            String msg=i.getStringExtra("message"); if(msg!=null) status.setText(msg);
            refresh();
        }
    };
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(24,30,24,20);root.setBackgroundColor(Color.rgb(246,248,252));
        ScrollView scroll=new ScrollView(this);scroll.addView(root);setContentView(scroll);
        TextView heading=new TextView(this);heading.setText("CallLab");heading.setTextSize(30);heading.setTextColor(Color.rgb(20,28,45));root.addView(heading);
        TextView info=new TextView(this);info.setText("V0.1 • Yerel mikrofon kayıt testi\nTelefon görüşmesinin karşı tarafını kaydetmez.");info.setTextSize(14);root.addView(info);
        status=new TextView(this);status.setText("Hazır");status.setPadding(0,25,0,12);root.addView(status);
        Button start=button("● Mikrofon kaydını başlat",()->startRecording());
        Button stop=button("■ Kaydı durdur",()->stopRecording());
        button("Shizuku kurulumunu kontrol et",()->checkShizuku());
        button("Kayıt listesini yenile",()->refresh());
        TextView label=new TextView(this);label.setText("Kayıtlar (dinlemek için dokun)");label.setTextSize(20);label.setPadding(0,24,0,8);root.addView(label);
        files=new LinearLayout(this);files.setOrientation(LinearLayout.VERTICAL);root.addView(files);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},12);
        refresh();
    }
    private Button button(String label,Runnable action) {
        Button b=new Button(this);b.setText(label);b.setAllCaps(false);root.addView(b);b.setOnClickListener(v->action.run());return b;
    }
    private void startRecording() {
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},10);return;
        }
        try { Intent i=new Intent(this,RecordingService.class);i.setAction(RecordingService.ACTION_START);startForegroundService(i);status.setText("Kayıt başlatılıyor…"); }
        catch(Exception e) { status.setText("Başlatılamadı: "+e.getMessage()); }
    }
    private void stopRecording() {
        Intent i=new Intent(this,RecordingService.class);i.setAction(RecordingService.ACTION_STOP);startService(i);status.setText("Kayıt durduruluyor…");
    }
    private void checkShizuku() {
        try { getPackageManager().getPackageInfo("moe.shizuku.privileged.api",0);
            status.setText("Shizuku yüklü. Bu sürüm Shizuku yetkisi istemez; kayıt motoruna henüz bağlı değil."); }
        catch(PackageManager.NameNotFoundException e) {status.setText("Shizuku yüklü değil.");}
    }
    private void refresh() {
        if(files==null)return;files.removeAllViews();
        File dir=new File(getFilesDir(),"recordings");File[] list=dir.listFiles((d,name)->name.endsWith(".m4a"));
        if(list==null||list.length==0) {TextView t=new TextView(this);t.setText("Henüz kayıt yok.");files.addView(t);return;}
        Arrays.sort(list,(a,b)->Long.compare(b.lastModified(),a.lastModified()));
        for(File f:list) {
            LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setPadding(0,10,0,10);files.addView(item);
            TextView t=new TextView(this);t.setText(f.getName()+"\n"+(f.length()/1024)+" KB");t.setTextSize(15);item.addView(t);
            Button play=new Button(this);play.setAllCaps(false);play.setText("▶ Dinle / Durdur");item.addView(play);
            play.setOnClickListener(v->{
                try {
                    if(player!=null){player.release();player=null;status.setText("Oynatma durduruldu");return;}
                    player=new MediaPlayer();player.setDataSource(f.getAbsolutePath());player.setOnCompletionListener(mp->{mp.release();player=null;status.setText("Oynatma tamamlandı");});player.prepare();player.start();status.setText("Oynatılıyor: "+f.getName());
                } catch(Exception e) {status.setText("Oynatılamadı: "+e.getMessage());if(player!=null){player.release();player=null;}}
            });
            Button delete=new Button(this);delete.setAllCaps(false);delete.setText("Sil");item.addView(delete);
            delete.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Kaydı sil?").setMessage(f.getName()).setNegativeButton("İptal",null).setPositiveButton("Sil",(d,w)->{f.delete();refresh();}).show());
        }
    }
    @Override public void onRequestPermissionsResult(int req,String[] perms,int[] grants) {
        super.onRequestPermissionsResult(req,perms,grants);
        if(req==10 && grants.length>0 && grants[0]==PackageManager.PERMISSION_GRANTED)startRecording();
    }
    @Override public void onStart(){super.onStart();IntentFilter filter=new IntentFilter(RecordingService.ACTION_CHANGED);if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,filter,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,filter);}
    @Override public void onStop(){unregisterReceiver(receiver);super.onStop();}
    @Override public void onDestroy(){if(player!=null){player.release();player=null;}super.onDestroy();}
}
