package com.example.calllab

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import rikka.shizuku.Shizuku
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Diagnostic prototype. Does NOT capture call downlink audio. */
class MainActivity : Activity() {
    private lateinit var status: TextView
    private var recorder: MediaRecorder? = null
    private var output: File? = null
    private val requestCode = 401
    private val permissionListener = Shizuku.OnRequestPermissionResultListener { code, result ->
        if (code == requestCode) runOnUiThread { status.text = if (result == PackageManager.PERMISSION_GRANTED) "Shizuku izni verildi" else "Shizuku izni reddedildi" }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(36, 45, 36, 20) }
        fun addButton(label: String, action: () -> Unit) { column.addView(Button(this).apply { text = label; setOnClickListener { action() } }) }
        column.addView(TextView(this).apply { text = "CallLab — Deneysel Kayıt Testi"; textSize = 23f })
        column.addView(TextView(this).apply { text = "Bu sürüm yalnızca mikrofon testi yapar. Telefon görüşmesinin karşı tarafını kaydettiğini iddia etmez. Kayıt öncesinde ilgili kişileri bilgilendirin."; textSize = 15f })
        status = TextView(this).apply { text = "Hazır"; textSize = 17f; setPadding(0, 24, 0, 24) }
        column.addView(status)
        addButton("Shizuku durumunu kontrol et") { checkShizuku() }
        addButton("Shizuku izni iste") { requestShizuku() }
        addButton("Mikrofon testini başlat") { startMic() }
        addButton("Kaydı durdur") { stopMic() }
        addButton("Kayıtları listele") { listFiles() }
        setContentView(ScrollView(this).apply { addView(column) })
        Shizuku.addRequestPermissionResultListener(permissionListener)
    }
    private fun checkShizuku() {
        status.text = try {
            if (!Shizuku.pingBinder()) "Shizuku çalışmıyor"
            else "Shizuku çalışıyor. API: ${Shizuku.getVersion()}, UID: ${Shizuku.getUid()}, izin: ${Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED}"
        } catch (e: Exception) { "Shizuku hatası: ${e.message}" }
    }
    private fun requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) { status.text = "Önce Shizuku'yu başlatın"; return }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) { status.text = "Shizuku izni zaten var"; return }
            Shizuku.requestPermission(requestCode)
        } catch (e: Exception) { status.text = "İzin hatası: ${e.message}" }
    }
    private fun startMic() {
        if (recorder != null) { status.text = "Kayıt zaten sürüyor"; return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 501); status.text = "Mikrofon iznini verip yeniden başlatın"; return
        }
        try {
            val folder = getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: filesDir
            output = File(folder, "mic_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.m4a")
            @Suppress("DEPRECATION")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(128000)
            r.setAudioSamplingRate(44100)
            r.setOutputFile(output!!.absolutePath)
            r.prepare(); r.start(); recorder = r
            status.text = "Mikrofon kaydı başladı (görüşme sesi değil)"
        } catch (e: Exception) { recorder?.release(); recorder = null; status.text = "Kayıt hatası: ${e.message}" }
    }
    private fun stopMic() {
        val r = recorder ?: run { status.text = "Aktif kayıt yok"; return }
        try { r.stop(); status.text = "Kaydedildi: ${output?.absolutePath}" }
        catch (e: Exception) { output?.delete(); status.text = "Kayıt başarısız: ${e.message}" }
        finally { r.release(); recorder = null }
    }
    private fun listFiles() {
        val folder = getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: filesDir
        status.text = folder.listFiles()?.filter { it.extension == "m4a" }?.joinToString("\n") { "${it.name} (${it.length()} bayt)" }?.ifEmpty { "Kayıt bulunamadı" } ?: "Kayıt bulunamadı"
    }
    override fun onDestroy() { if (recorder != null) stopMic(); Shizuku.removeRequestPermissionResultListener(permissionListener); super.onDestroy() }
}
