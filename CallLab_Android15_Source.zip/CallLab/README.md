# CallLab v0.1 — Android 15 / HyperOS 2 diagnostic prototype

Independent Kotlin source; no other recorder code included. Shizuku API is used solely for service-status and permission checks. No root, no INTERNET permission, no analytics. Microphone-only recording (M4A) for initial audio pipeline testing. **Does not record both sides of calls** and does not claim privileged audio access. Android restrictions on VOICE_CALL/VOICE_UPLINK/VOICE_DOWNLINK and CAPTURE_AUDIO_OUTPUT cannot be bypassed merely by installing Shizuku.

## Build
Open project in Android Studio (JDK 17), sync Gradle and build APK. Or push to GitHub and run the included workflow. APK will appear in the Actions artifacts. Internet is needed at build time to fetch Gradle dependencies, not by the installed app.

## Safety
Record only with appropriate notice/consent and in compliance with local law. Local files: app-specific external Music directory, removed on uninstall. Test on a separate non-sensitive recording before use.

## Roadmap
1. Verify Shizuku API and microphone on target hardware.
2. Investigate Android's permission and audio-policy behavior using authorized diagnostics; don't assume shell UID grants call capture.
3. Only after verifying a supported path, add call state and foreground service; avoid silently recording calls.
